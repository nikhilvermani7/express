var http = require("http");

//var {requestHandler} = require ("./requesthandler");

//  var server= http.createServer(requestHandler);

const app = require("./server");
var server= http.createServer(app);
   


 server.listen(6100,(err)=>
 {
     if(err)
     {
            console.log("coulnot start");
            return;
     }
     console.log("sevr started at port xxxx");
 })

 