const express = require("express");
var router = express.Router();

var products = [
    { id: 1, name: "apple", quantity: 10, price: 20 },
    { id: 2, name: "mango", quantity: 10, price: 30 },
    { id: 3, name: "orangeeeeee", quantity: 10, price: 40 },
    { id: 4, name: "blueberry", quantity: 10, price: 60 },
]

router.get("/", (req, res) => {
    res.header("content-type", "text/html").send("products");
})

router.get("/lists", (req, res) => {
    var model = {
        caption: "products-lists",
        items: products
    };
    res.header("content-type", "text/html").render("products-lists", model);
})


router.get("/add", (req, res) => {
    res.header("content-type", "text/html").render("add");
})


module.exports = router;